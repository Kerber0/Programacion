public class Main {
    public static void main(String[] args) {

        Cli gestor = new Cli();

        gestor.inicio();

    }
}